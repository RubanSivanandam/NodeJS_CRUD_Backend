// Importing the Pool class from the "pg" module, which is used to interact with PostgreSQL
const Pool = require("pg").Pool;

// Creating a new instance of the Pool class with connection configuration options
const postg = new Pool({
    user: "postgres",          // Username for connecting to the PostgreSQL database
    host: "localhost",         // Hostname where the PostgreSQL database is running
    database: "employee",      // Name of the database to connect to
    password: "postgres",      // Password for the specified user
    port: 5432                 // Port on which the PostgreSQL database is listening for connections
});

// Exporting the created pool instance to make it available for other modules
module.exports = postg;