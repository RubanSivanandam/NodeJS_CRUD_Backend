// Importing the PostgreSQL and MongoDB configuration files
const postg = require('../config/postgresDB');
const mongo = require('../config/mongodb');

// Function to create a new employee
const createEmployee = (req, resp) => {
    // Extracting data from request body
    const { id, first_name, last_name, designation, phone_number } = req.body;

    // PostgreSQL query to insert new employee data into the database
    const pgQuery = `INSERT INTO employee (id, first_name, last_name, designation, phone_number) VALUES ($1, $2, $3, $4, $5)`;

    // Executing the PostgreSQL query
    postg.query(pgQuery, [id, first_name, last_name, designation, phone_number], (pgError, pgResults) => {
        if (pgError) {
            console.error('PostgreSQL Error:', pgError);
            resp.status(500).send("Internal Server Error");
            return;
        }

        // Success response
        resp.status(201).send("Employee created successfully");

        // MongoDB operation
        mongo()
            .then(({ client, database }) => {
                // Accessing the 'employees' collection in the MongoDB database
                const collection = database.collection('employee');

                // Inserting the new employee document into the collection
                collection.insertOne({
                    id,
                    first_name,
                    last_name,
                    designation,
                    phone_number
                }, (mongoError, mongoResult) => {
                    // Handling errors
                    if (mongoError) {
                        console.error('MongoDB Error:', mongoError);
                        return;
                    }

                    // Logging success
                    console.log("Employee inserted into MongoDB successfully");

                    // Closing the MongoDB connection
                    client.close();
                });
            })
            .catch(mongoError => {
                // Handling errors
                console.error('MongoDB Connection Error:', mongoError);
            });
    });
};

// Function to update an existing employee
const UpdateEmployee = (req, resp) => {
    // Extracting data from request body
    const { id, first_name, last_name, designation, phone_number } = req.body;

    // PostgreSQL query to update employee data in the database
    const pgQuery = `UPDATE employee SET first_name = $1, last_name = $2, designation = $3, phone_number = $4 WHERE id = $5`;

    // Executing the PostgreSQL query
    postg.query(pgQuery, [first_name, last_name, designation, phone_number, id], (pgError, pgResults) => {
        if (pgError) {
            console.error('PostgreSQL Error:', pgError);
            resp.status(500).send("Internal Server Error");
            return;
        }

        // Success response
        resp.status(200).send("Employee updated successfully");

        // MongoDB operation
        mongo()
            .then(({ client, database }) => {
                // Accessing the 'employees' collection in the MongoDB database
                const collection = database.collection('employee');

                // Updating the employee document in the collection
                collection.updateOne(
                    { id: id },
                    { $set: { first_name, last_name, designation, phone_number } },
                    (mongoError, mongoResult) => {
                        // Handling errors
                        if (mongoError) {
                            console.error('MongoDB Error:', mongoError);
                            return;
                        }

                        // Logging success
                        console.log("Employee updated in MongoDB successfully");

                        // Closing the MongoDB connection
                        client.close();
                    }
                );
            })
            .catch(mongoError => {
                // Handling errors
                console.error('MongoDB Connection Error:', mongoError);
            });
    });
};

// Function to delete an employee
const deleteEmployee = (req, resp) => {
    // Extracting employee id from request parameters
    const id = parseInt(req.params.id);

    // PostgreSQL query to delete employee from the database based on id
    const pgQuery = 'DELETE FROM employee WHERE id = $1';

    // Executing the PostgreSQL query
    postg.query(pgQuery, [id], (pgError, pgResults) => {
        if (pgError) {
            console.error('PostgreSQL Error:', pgError);
            resp.status(500).send("Internal Server Error");
            return;
        }

        // Success response
        resp.status(200).send("Employee deleted successfully");

        // MongoDB operation
        mongo()
            .then(({ client, database }) => {
                // Accessing the 'employees' collection in the MongoDB database
                const collection = database.collection('employee');

                // Deleting the employee document from the collection
                collection.deleteOne({ id: id }, (mongoError, mongoResult) => {
                    // Handling errors
                    if (mongoError) {
                        console.error('MongoDB Error:', mongoError);
                        return;
                    }

                    // Logging success
                    console.log("Employee deleted from MongoDB successfully");

                    // Closing the MongoDB connection
                    client.close();
                });
            })
            .catch(mongoError => {
                // Handling errors
                console.error('MongoDB Connection Error:', mongoError);
            });
    });
};

// Function to retrieve all employees
const getEmployees = (req, resp) => {
    // PostgreSQL query to select all employees from the database
    const pgQuery = 'SELECT * FROM employee';

    // Executing the PostgreSQL query
    postg.query(pgQuery, (pgError, pgResults) => {
        if (pgError) {
            console.error('PostgreSQL Error:', pgError);
            resp.status(500).send("Internal Server Error");
            return;
        }

        // Success response
        resp.status(200).send(pgResults.rows);

        // MongoDB operation
        mongo()
            .then(({ client, database }) => {
                // Accessing the 'employees' collection in the MongoDB database
                const collection = database.collection('employee');

                // Retrieving all employees from the collection
                collection.find({}).toArray((mongoError, employees) => {
                    // Handling errors
                    if (mongoError) {
                        console.error('MongoDB Error:', mongoError);
                        return;
                    }

                    // Logging success
                    console.log("All Employees retrieved from MongoDB successfully");

                    // Closing the MongoDB connection
                    client.close();
                });
            })
            .catch(mongoError => {
                // Handling errors
                console.error('MongoDB Connection Error:', mongoError);
            });
    });
};

// Function to retrieve an employee by id
const getByEmployeeId = (req, resp) => {
    // Extracting employee id from request parameters
    const id = parseInt(req.params.id);

    // PostgreSQL query to select employee by id from the database
    const pgQuery = 'SELECT * FROM employee WHERE id = $1';

    // Executing the PostgreSQL query
    postg.query(pgQuery, [id], (pgError, pgResults) => {
        if (pgError) {
            console.error('PostgreSQL Error:', pgError);
            resp.status(500).send("Internal Server Error");
            return;
        }

        // Success response
        resp.status(200).send(pgResults.rows);

        // MongoDB operation
        mongo()
            .then(({ client, database }) => {
                // Accessing the 'employees' collection in the MongoDB database
                const collection = database.collection('employee');

                // Retrieving the employee by ID from the collection
                collection.findOne({ id: id }, (mongoError, employee) => {
                    // Handling errors
                    if (mongoError) {
                        console.error('MongoDB Error:', mongoError);
                        return;
                    }

                    // Logging success
                    console.log(`Employee with ID ${id} retrieved from MongoDB successfully`);

                    // Closing the MongoDB connection
                    client.close();
                });
            })
            .catch(mongoError => {
                // Handling errors
                console.error('MongoDB Connection Error:', mongoError);
            });
    });
};
let id=1
const testidCreation= (req, resp) => {
 id=id+1;
 resp.status(200).send({id:id});
}

// Exporting functions to be used in the route layer
module.exports = {
    createEmployee,
    deleteEmployee,
    getByEmployeeId,
    getEmployees,
    UpdateEmployee,
    testidCreation
};
